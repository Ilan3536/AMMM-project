package edu.upc.fib.ammm.model;

public record Box(int width, int height, int maxWeight) {
}
